
public class Book {

	public String isbn;
	public String crYear;
	public String license;
	public String title;
	public String contrib;
	public String publ;
	public String desc;
	
	
	public String toStr(){
		String output = "";
		
		if(this.title.length()!=0) output+="Title: "+this.title;
		if(this.crYear.length()!=0) output += " Copyright Year: "+this.crYear;
		if(this.contrib.length()!=0) output+= " Contributor: "+this.contrib;
		if(this.publ.length()!=0) output+=" Publisher: "+this.publ;
		if(this.license.length()!=0) output+=" License: "+this.license;
		if(this.isbn.length()!=0) output+="ISBN13: "+this.isbn;
		if(this.desc.length()!=0) output+="\nDescription: "+ this.desc;
		
		return output;
	}
	
}
