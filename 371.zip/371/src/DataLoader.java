import java.io.FileReader;
import java.io.Reader;
import java.util.LinkedList;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

public class DataLoader {
	public static LinkedList<Book> loadBook() throws Exception{
		LinkedList<Book> bookList = new LinkedList<>();
		Reader in = new FileReader("textbooks3C.csv");
		Iterable<CSVRecord> records = CSVFormat.EXCEL.withFirstRecordAsHeader().parse(in);
		for (CSVRecord record : records) {
		    Book temp = new Book();
		    temp.title = record.get("﻿Title");
		    temp.crYear = record.get("Copyright Year");
		    temp.contrib = record.get("Contributors");
		    temp.publ = record.get("Publisher");
		    temp.license = record.get("License");
		    temp.desc = record.get("Description");
		    temp.isbn = record.get("ISBN13");
		    bookList.add(temp);
		}
		return bookList;
	}
}
