import java.util.LinkedList;
import java.util.Scanner;

public class Main {
	private static LinkedList<Book> bookList = new LinkedList<Book>();
	public static void main(String arg[]) throws Exception{
		bookList = DataLoader.loadBook();
		while (true){
			Scanner input = new Scanner(System.in);
			System.out.println("Enter the exact ISBN13 book id:");
			String isbn = input.nextLine();
			System.out.println(findBook(isbn));
		}
	}
	private static String findBook(String isbn) {
		// TODO Auto-generated method stub.
		for(int i = 0; i<bookList.size();i++){
			Book current = bookList.get(i);
			if(current.isbn.equals(isbn)){
				return current.toStr();
			}
		}
		return "Not Found :<";
	}
}
